"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MapPin, Camera, Coins, Users, TrendingUp, AlertTriangle } from "lucide-react"
import Link from "next/link"

export default function DashboardPage() {
  const stats = [
    { title: "Issues Reported", value: "23", icon: AlertTriangle, color: "text-[#ed4245]" },
    { title: "CivicCoins Earned", value: "450", icon: Coins, color: "text-[#faa81a]" },
    { title: "Community Rank", value: "#12", icon: TrendingUp, color: "text-[#3ba55d]" },
    { title: "Active Citizens", value: "1.2K", icon: Users, color: "text-[#5865f2]" },
  ]

  const recentIssues = [
    { id: 1, title: "Pothole on Main Street", status: "In Progress", date: "2 days ago" },
    { id: 2, title: "Broken Streetlight", status: "Resolved", date: "1 week ago" },
    { id: 3, title: "Water Leak", status: "Pending", date: "3 days ago" },
  ]

  return (
    <div className="min-h-screen bg-[var(--discord-bg-tertiary)] p-4">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-[var(--discord-text-primary)]">Citizen Dashboard</h1>
              <p className="text-[var(--discord-text-secondary)]">
                Welcome back! Here's your civic engagement overview.
              </p>
            </div>
          </div>
          <Button className="bg-[#3ba55d] hover:bg-[#2d7d32] text-white">
            <Camera className="w-4 h-4 mr-2" />
            Report Issue
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-[var(--discord-text-secondary)]">{stat.title}</p>
                      <p className="text-2xl font-bold text-[var(--discord-text-primary)]">{stat.value}</p>
                    </div>
                    <stat.icon className={`w-8 h-8 ${stat.color}`} />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
            <CardHeader>
              <CardTitle className="text-[var(--discord-text-primary)]">Recent Issues</CardTitle>
              <CardDescription className="text-[var(--discord-text-secondary)]">
                Your latest reported civic issues
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentIssues.map((issue) => (
                  <div
                    key={issue.id}
                    className="flex items-center justify-between p-3 bg-[var(--discord-bg-primary)] rounded-lg"
                  >
                    <div>
                      <h4 className="font-medium text-[var(--discord-text-primary)]">{issue.title}</h4>
                      <p className="text-sm text-[var(--discord-text-secondary)]">{issue.date}</p>
                    </div>
                    <span
                      className={`px-2 py-1 rounded-full text-xs ${
                        issue.status === "Resolved"
                          ? "bg-[#3ba55d]/20 text-[#3ba55d]"
                          : issue.status === "In Progress"
                            ? "bg-[#faa81a]/20 text-[#faa81a]"
                            : "bg-[#ed4245]/20 text-[#ed4245]"
                      }`}
                    >
                      {issue.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
            <CardHeader>
              <CardTitle className="text-[var(--discord-text-primary)]">Quick Actions</CardTitle>
              <CardDescription className="text-[var(--discord-text-secondary)]">
                Common tasks and features
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant="outline"
                  className="h-20 flex-col gap-2 border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                >
                  <Camera className="w-6 h-6" />
                  <span className="text-sm">Report Issue</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex-col gap-2 border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                >
                  <MapPin className="w-6 h-6" />
                  <span className="text-sm">View Map</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex-col gap-2 border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                >
                  <Coins className="w-6 h-6" />
                  <span className="text-sm">My Rewards</span>
                </Button>
                <Button
                  variant="outline"
                  className="h-20 flex-col gap-2 border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                >
                  <Users className="w-6 h-6" />
                  <span className="text-sm">Community</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
