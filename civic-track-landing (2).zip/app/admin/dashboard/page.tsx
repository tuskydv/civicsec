"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Users, AlertTriangle, CheckCircle, Clock, TrendingUp, MapPin } from "lucide-react"
import Link from "next/link"

export default function AdminDashboardPage() {
  const stats = [
    { title: "Total Issues", value: "1,234", icon: AlertTriangle, color: "text-[#ed4245]", change: "+12%" },
    { title: "Resolved Issues", value: "987", icon: CheckCircle, color: "text-[#3ba55d]", change: "+8%" },
    { title: "Pending Issues", value: "247", icon: Clock, color: "text-[#faa81a]", change: "-5%" },
    { title: "Active Citizens", value: "5,678", icon: Users, color: "text-[#5865f2]", change: "+15%" },
  ]

  const recentIssues = [
    { id: 1, title: "Water Main Break - Downtown", priority: "High", reporter: "John Doe", time: "2 hours ago" },
    { id: 2, title: "Pothole on Oak Street", priority: "Medium", reporter: "Jane Smith", time: "4 hours ago" },
    { id: 3, title: "Broken Traffic Light", priority: "High", reporter: "Mike Johnson", time: "6 hours ago" },
    { id: 4, title: "Graffiti Removal Request", priority: "Low", reporter: "Sarah Wilson", time: "1 day ago" },
  ]

  return (
    <div className="min-h-screen bg-[var(--discord-bg-tertiary)] p-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link
              href="/"
              className="inline-flex items-center gap-2 text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-[var(--discord-text-primary)]">Admin Dashboard</h1>
              <p className="text-[var(--discord-text-secondary)]">Municipal management and oversight panel</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Button
              variant="outline"
              className="border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
            >
              <MapPin className="w-4 h-4 mr-2" />
              View Map
            </Button>
            <Button className="bg-[#5865f2] hover:bg-[#4752c4] text-white">Generate Report</Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <stat.icon className={`w-8 h-8 ${stat.color}`} />
                    <span
                      className={`text-sm font-medium ${
                        stat.change.startsWith("+") ? "text-[#3ba55d]" : "text-[#ed4245]"
                      }`}
                    >
                      {stat.change}
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-[var(--discord-text-primary)] mb-1">{stat.value}</p>
                  <p className="text-sm text-[var(--discord-text-secondary)]">{stat.title}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
              <CardHeader>
                <CardTitle className="text-[var(--discord-text-primary)]">Recent Issues</CardTitle>
                <CardDescription className="text-[var(--discord-text-secondary)]">
                  Latest reported civic issues requiring attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentIssues.map((issue) => (
                    <div
                      key={issue.id}
                      className="flex items-center justify-between p-4 bg-[var(--discord-bg-primary)] rounded-lg"
                    >
                      <div className="flex-1">
                        <h4 className="font-medium text-[var(--discord-text-primary)] mb-1">{issue.title}</h4>
                        <div className="flex items-center gap-4 text-sm text-[var(--discord-text-secondary)]">
                          <span>Reported by {issue.reporter}</span>
                          <span>{issue.time}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span
                          className={`px-3 py-1 rounded-full text-xs font-medium ${
                            issue.priority === "High"
                              ? "bg-[#ed4245]/20 text-[#ed4245]"
                              : issue.priority === "Medium"
                                ? "bg-[#faa81a]/20 text-[#faa81a]"
                                : "bg-[#3ba55d]/20 text-[#3ba55d]"
                          }`}
                        >
                          {issue.priority}
                        </span>
                        <Button
                          size="sm"
                          variant="outline"
                          className="border-[var(--discord-bg-tertiary)] bg-transparent"
                        >
                          Review
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
              <CardHeader>
                <CardTitle className="text-[var(--discord-text-primary)]">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button className="w-full justify-start bg-[#3ba55d] hover:bg-[#2d7d32] text-white">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Approve Issues
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                  >
                    <Users className="w-4 h-4 mr-2" />
                    Manage Users
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full justify-start border-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent"
                  >
                    <TrendingUp className="w-4 h-4 mr-2" />
                    View Analytics
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
              <CardHeader>
                <CardTitle className="text-[var(--discord-text-primary)]">System Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--discord-text-secondary)]">AI Verification</span>
                    <span className="text-sm text-[#3ba55d]">Online</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--discord-text-secondary)]">Blockchain Network</span>
                    <span className="text-sm text-[#3ba55d]">Connected</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--discord-text-secondary)]">Database</span>
                    <span className="text-sm text-[#3ba55d]">Healthy</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--discord-text-secondary)]">API Status</span>
                    <span className="text-sm text-[#3ba55d]">Operational</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
