import { action } from '@uibakery/data';

function loadIssues() {
  return action('loadIssues', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      SELECT 
        i.id,
        i.user_id,
        i.title,
        i.description,
        i.category_id,
        c.name as category_name,
        i.latitude as lat,
        i.longitude as lng,
        i.address,
        i.status,
        i.is_anonymous,
        i.is_hidden,
        i.created_at,
        i.updated_at,
        COALESCE(f.flag_count, 0) as flag_count
      FROM issues i
      INNER JOIN categories c ON i.category_id = c.id
      LEFT JOIN (
        SELECT issue_id, COUNT(*) as flag_count
        FROM issue_flags
        GROUP BY issue_id
      ) f ON i.id = f.issue_id
      WHERE i.is_hidden = FALSE
        AND (COALESCE({{params.status}}, '') = '' OR i.status = {{params.status}})
        AND (COALESCE({{params.categoryId}}, 0) = 0 OR i.category_id = {{params.categoryId}})
      ORDER BY i.created_at DESC
      LIMIT 100;
    `,
  });
}

export default loadIssues;
