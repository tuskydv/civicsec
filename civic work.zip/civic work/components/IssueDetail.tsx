// Component to display detailed view of a civic issue
import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useMutateAction } from '@uibakery/data';
import { ArrowLeft, MapPin, Clock, Flag, Shield, CheckCircle, AlertCircle, Clock4 } from 'lucide-react';
import updateIssueStatusAction from '@/actions/updateIssueStatus';
import flagIssueAction from '@/actions/flagIssue';
import type { Issue } from '@/types';

interface IssueDetailProps {
  issue?: Issue;
  onBack?: () => void;
  onStatusUpdated?: () => void;
  isAdmin?: boolean;
}

export function IssueDetail({ issue, onBack, onStatusUpdated, isAdmin = false }: IssueDetailProps) {
  // If no issue provided, this could be a route-based detail view
  if (!issue) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Issue not found or loading...</p>
      </div>
    );
  }
  const [flagReason, setFlagReason] = useState('');
  const [showFlagDialog, setShowFlagDialog] = useState(false);
  const [newStatus, setNewStatus] = useState(issue.status);

  const [updateStatus, isUpdatingStatus, updateError] = useMutateAction(updateIssueStatusAction);
  const [flagIssue, isFlagging, flagError] = useMutateAction(flagIssueAction);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Reported': return <AlertCircle className="h-4 w-4" />;
      case 'In Progress': return <Clock4 className="h-4 w-4" />;
      case 'Resolved': return <CheckCircle className="h-4 w-4" />;
      default: return <AlertCircle className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Reported': return 'bg-red-100 text-red-800 border-red-200';
      case 'In Progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Resolved': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const handleStatusUpdate = async () => {
    if (newStatus === issue.status) return;

    try {
      await updateStatus({
        issueId: issue.id,
        status: newStatus,
      });
      console.log('Issue status updated successfully');
      onStatusUpdated?.();
    } catch (error) {
      console.error('Failed to update issue status:', error);
    }
  };

  const handleFlag = async () => {
    if (!flagReason.trim()) return;

    try {
      await flagIssue({
        issueId: issue.id,
        userId: null, // Anonymous flagging for now
        reason: flagReason,
      });
      console.log('Issue flagged successfully');
      setFlagReason('');
      setShowFlagDialog(false);
    } catch (error) {
      console.error('Failed to flag issue:', error);
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        {onBack && (
          <Button variant="ghost" size="sm" onClick={onBack}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
        )}
        <h1 className="text-2xl font-bold">Issue Details</h1>
      </div>

      {/* Main Issue Card */}
      <Card>
        <CardHeader>
          <div className="flex flex-col gap-3">
            <div className="flex items-start justify-between gap-3">
              <CardTitle className="text-xl">{issue.title}</CardTitle>
              <div className="flex items-center gap-2 shrink-0">
                <Badge className={`${getStatusColor(issue.status)} flex items-center gap-1`}>
                  {getStatusIcon(issue.status)}
                  {issue.status}
                </Badge>
                <Badge variant="outline">
                  {issue.category_name}
                </Badge>
              </div>
            </div>
            
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <div className="flex items-center gap-1">
                <Clock className="h-4 w-4" />
                Reported: {formatDate(issue.created_at)}
              </div>
              {issue.updated_at !== issue.created_at && (
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4" />
                  Updated: {formatDate(issue.updated_at)}
                </div>
              )}
            </div>

            {issue.flag_count && issue.flag_count > 0 && (
              <Alert variant="destructive">
                <Flag className="h-4 w-4" />
                <AlertDescription>
                  This issue has been flagged {issue.flag_count} time{issue.flag_count > 1 ? 's' : ''} by the community.
                </AlertDescription>
              </Alert>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold mb-2">Description</h3>
            <p className="text-gray-700 whitespace-pre-wrap">{issue.description}</p>
          </div>

          <div>
            <h3 className="font-semibold mb-2 flex items-center gap-1">
              <MapPin className="h-4 w-4" />
              Location
            </h3>
            <p className="text-gray-700">
              {issue.address || `Lat: ${issue.location.lat.toFixed(6)}, Lng: ${issue.location.lng.toFixed(6)}`}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              Coordinates: {issue.location.lat.toFixed(6)}, {issue.location.lng.toFixed(6)}
            </p>
          </div>

          <div className="flex items-center gap-2 text-sm text-gray-600">
            {issue.is_anonymous && (
              <Badge variant="secondary">Anonymous Report</Badge>
            )}
            <span>Issue ID: #{issue.id}</span>
          </div>
        </CardContent>
      </Card>

      {/* Admin Actions */}
      {isAdmin && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-blue-600" />
              Admin Actions
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <label className="text-sm font-medium min-w-fit">Update Status:</label>
              <Select value={newStatus} onValueChange={(value) => setNewStatus(value as typeof newStatus)}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Reported">Reported</SelectItem>
                  <SelectItem value="In Progress">In Progress</SelectItem>
                  <SelectItem value="Resolved">Resolved</SelectItem>
                </SelectContent>
              </Select>
              <Button
                onClick={handleStatusUpdate}
                disabled={isUpdatingStatus || newStatus === issue.status}
                size="sm"
              >
                {isUpdatingStatus ? 'Updating...' : 'Update'}
              </Button>
            </div>

            {updateError && (
              <Alert variant="destructive">
                <AlertDescription>
                  Failed to update status. Please try again.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Community Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Community Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <Dialog open={showFlagDialog} onOpenChange={setShowFlagDialog}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex items-center gap-2">
                <Flag className="h-4 w-4" />
                Flag as Inappropriate
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Flag Issue</DialogTitle>
                <DialogDescription>
                  Help us maintain quality by reporting issues that are spam, inappropriate, or don't belong here.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <Textarea
                  placeholder="Please explain why you're flagging this issue..."
                  value={flagReason}
                  onChange={(e) => setFlagReason(e.target.value)}
                  rows={3}
                />
                {flagError && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      Failed to flag issue. Please try again.
                    </AlertDescription>
                  </Alert>
                )}
                <div className="flex gap-2 justify-end">
                  <Button variant="outline" onClick={() => setShowFlagDialog(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleFlag}
                    disabled={isFlagging || !flagReason.trim()}
                  >
                    {isFlagging ? 'Submitting...' : 'Submit Flag'}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>
    </div>
  );
}
