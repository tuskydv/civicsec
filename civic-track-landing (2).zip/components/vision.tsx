"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export function Vision() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  const visionStats = [
    {
      number: "50K",
      label: "Citizens Empowered",
      description: "Active users transforming cities across India with verified reports",
      gradient: "from-[#5865f2] to-[#4752c4]",
    },
    {
      number: "500",
      label: "Smart Cities",
      description: "Government partnerships established nationwide for digital governance",
      gradient: "from-[#3ba55d] to-[#2d7d32]",
    },
    {
      number: "99%",
      label: "AI Accuracy",
      description: "Precision in issue detection, categorization, and resolution tracking",
      gradient: "from-[#faa81a] to-[#e8890b]",
    },
    {
      number: "2hrs",
      label: "Avg Resolution",
      description: "Lightning-fast response time through intelligent routing and automation",
      gradient: "from-[#ed4245] to-[#c23616]",
    },
  ]

  return (
    <section id="vision" className="px-4 py-20" ref={ref}>
      <div className="mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[var(--discord-text-primary)] mb-4">
            Our{" "}
            <span className="bg-gradient-to-r from-[#5865f2] via-[#3ba55d] to-[#faa81a] bg-clip-text text-transparent">
              2025 Vision
            </span>
          </h2>
          <p className="text-xl text-[var(--discord-text-secondary)] max-w-3xl mx-auto">
            Revolutionizing Indian governance with AI-powered civic engagement, blockchain transparency, and
            community-driven solutions.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {visionStats.map((stat, index) => (
            <motion.div
              key={index}
              className="relative group"
              initial={{ opacity: 0, y: 50 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                delay: index * 0.1,
                duration: 0.6,
                type: "spring",
                stiffness: 150,
              }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="bg-[var(--discord-bg-secondary)] border border-[var(--discord-bg-primary)] rounded-xl p-6 text-center h-full">
                <div
                  className={`text-4xl lg:text-5xl font-bold bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent mb-2`}
                >
                  {stat.number}
                </div>
                <h3 className="text-lg font-semibold text-[var(--discord-text-primary)] mb-2">{stat.label}</h3>
                <p className="text-sm leading-relaxed text-[var(--discord-text-secondary)]">{stat.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
