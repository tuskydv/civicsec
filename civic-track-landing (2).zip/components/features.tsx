"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Brain, Shield, Coins, Zap, Globe, Lock } from "lucide-react"

export function Features() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  const features = [
    {
      icon: Brain,
      title: "AI-Powered Verification",
      description:
        "Lightning-fast computer vision analyzes photos instantly, detects duplicates, and scores severity with 98% accuracy.",
      tags: ["Computer Vision", "Auto-categorization", "Duplicate Detection"],
      gradient: "from-[#5865f2] to-[#4752c4]",
    },
    {
      icon: Shield,
      title: "Blockchain Transparency",
      description:
        "Immutable ledger on Polygon stores issue hashes and updates for complete transparency and tamper-proof records.",
      tags: ["Immutable Records", "Smart Contracts", "Polygon Network"],
      gradient: "from-[#3ba55d] to-[#2d7d32]",
    },
    {
      icon: Coins,
      title: "CivicCoins Rewards",
      description:
        "Earn tokens for every verified report, vote, and resolution. Redeem for real rewards and exclusive benefits.",
      tags: ["Token Economy", "Leaderboards", "Real Rewards"],
      gradient: "from-[#faa81a] to-[#e8890b]",
    },
    {
      icon: Zap,
      title: "Real-Time Updates",
      description:
        "Instant notifications, live status tracking, and emergency alerts keep your community connected 24/7.",
      tags: ["Live Notifications", "Emergency Alerts", "Status Tracking"],
      gradient: "from-[#ed4245] to-[#c23616]",
    },
    {
      icon: Globe,
      title: "Universal Access",
      description:
        "PWA with offline mode, voice commands, AR lens, and 25+ languages ensuring everyone can participate.",
      tags: ["PWA", "Offline Mode", "AR Integration"],
      gradient: "from-[#5865f2] to-[#3ba55d]",
    },
    {
      icon: Lock,
      title: "Verified Identity",
      description: "Bank-level security with DigiLocker integration, Aadhaar verification, and zero-knowledge proofs.",
      tags: ["DigiLocker", "Aadhaar eKYC", "Zero-Knowledge"],
      gradient: "from-[#faa81a] to-[#5865f2]",
    },
  ]

  return (
    <section id="features" className="px-4 py-20" ref={ref}>
      <div className="mx-auto max-w-7xl">
        <motion.div
          className="text-center mb-16"
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-4xl lg:text-5xl font-bold text-[var(--discord-text-primary)] mb-4">
            Revolutionary Features
          </h2>
          <p className="text-xl text-[var(--discord-text-secondary)]">
            Cutting-edge technology meets lightning-fast civic engagement
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              className="relative group"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                delay: index * 0.08,
                duration: 0.5,
                type: "spring",
                stiffness: 200,
              }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="bg-[var(--discord-bg-secondary)] border border-[var(--discord-bg-primary)] rounded-xl p-6 h-full">
                <div
                  className={`w-12 h-12 bg-gradient-to-r ${feature.gradient} rounded-lg flex items-center justify-center mb-4 shadow-lg`}
                >
                  <feature.icon className="h-6 w-6 text-white" />
                </div>

                <h3 className="text-xl font-semibold text-[var(--discord-text-primary)] mb-3">{feature.title}</h3>

                <p className="text-[var(--discord-text-secondary)] mb-4 leading-relaxed">{feature.description}</p>

                <div className="flex flex-wrap gap-2">
                  {feature.tags.map((tag, tagIndex) => (
                    <motion.span
                      key={tagIndex}
                      className="px-3 py-1 bg-[var(--discord-bg-primary)] text-[var(--discord-text-secondary)] text-xs rounded-full border border-[var(--discord-bg-tertiary)]"
                      initial={{ opacity: 0, scale: 0 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{ delay: index * 0.08 + tagIndex * 0.05 + 0.3 }}
                      whileHover={{ scale: 1.05 }}
                    >
                      {tag}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
