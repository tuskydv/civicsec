"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Shield, Lock, Eye, EyeOff, AlertCircle } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export default function AdminLoginPage() {
  const [showPassword, setShowPassword] = useState(false)
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const router = useRouter()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    // Check admin credentials
    if (username === "admin" && password === "admin") {
      setTimeout(() => {
        setIsLoading(false)
        router.push("/admin/dashboard")
      }, 1500)
    } else {
      setTimeout(() => {
        setIsLoading(false)
        setError("Invalid credentials. Use admin/admin to login.")
      }, 1000)
    }
  }

  return (
    <div className="min-h-screen bg-[var(--discord-bg-tertiary)] flex items-center justify-center p-4">
      <motion.div
        className="w-full max-w-md"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] mb-8 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>

        <Card className="bg-[var(--discord-bg-secondary)] border-[var(--discord-bg-primary)]">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-[#5865f2] rounded-full flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <CardTitle className="text-2xl text-[var(--discord-text-primary)]">Admin Access</CardTitle>
            <CardDescription className="text-[var(--discord-text-secondary)]">
              Municipal admin login to management dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleLogin} className="space-y-4">
              {error && (
                <motion.div
                  className="flex items-center gap-2 p-3 bg-[#ed4245]/10 border border-[#ed4245]/20 rounded-lg"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <AlertCircle className="w-4 h-4 text-[#ed4245]" />
                  <span className="text-sm text-[#ed4245]">{error}</span>
                </motion.div>
              )}

              <div className="space-y-2">
                <Label htmlFor="username" className="text-[var(--discord-text-primary)]">
                  Username
                </Label>
                <div className="relative">
                  <Shield className="absolute left-3 top-3 h-4 w-4 text-[var(--discord-text-secondary)]" />
                  <Input
                    id="username"
                    type="text"
                    placeholder="Enter admin username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="pl-10 bg-[var(--discord-bg-primary)] border-[var(--discord-bg-tertiary)] text-[var(--discord-text-primary)]"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="text-[var(--discord-text-primary)]">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-[var(--discord-text-secondary)]" />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    placeholder="Enter admin password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-10 pr-10 bg-[var(--discord-bg-primary)] border-[var(--discord-bg-tertiary)] text-[var(--discord-text-primary)]"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)]"
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>

              <div className="text-xs text-[var(--discord-text-secondary)] bg-[var(--discord-bg-primary)] p-3 rounded-lg">
                <strong>Demo Credentials:</strong>
                <br />
                Username: admin
                <br />
                Password: admin
              </div>

              <Button type="submit" className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white" disabled={isLoading}>
                {isLoading ? "Authenticating..." : "Admin Login"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
