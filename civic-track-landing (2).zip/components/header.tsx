"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { Zap } from "lucide-react"

interface HeaderProps {
  onGetStarted: () => void
}

export function Header({ onGetStarted }: HeaderProps) {
  return (
    <motion.header
      className="relative z-50 px-4 py-6 bg-[var(--discord-bg-secondary)]/80 backdrop-blur-sm border-b border-[var(--discord-bg-primary)]"
      initial={{ y: -50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between">
        <motion.div
          className="flex items-center space-x-3"
          whileHover={{ scale: 1.05 }}
          transition={{ type: "spring", stiffness: 400, damping: 15 }}
        >
          <div className="relative">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-[#5865f2] to-[#3ba55d] flex items-center justify-center shadow-lg">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#3ba55d] rounded-full border-2 border-[var(--discord-bg-secondary)]" />
          </div>
          <div>
            <span className="text-xl font-bold text-[var(--discord-text-primary)]">CivicTrack</span>
            <div className="text-xs text-[var(--discord-text-secondary)]">AI + Blockchain</div>
          </div>
        </motion.div>

        <div className="hidden md:flex items-center space-x-8">
          {["Features", "Vision", "Contact"].map((item, index) => (
            <motion.a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] transition-colors duration-200 font-medium"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + index * 0.05 }}
              whileHover={{ scale: 1.05 }}
            >
              {item}
            </motion.a>
          ))}
        </div>

        <div className="flex items-center space-x-4">
          <ThemeToggle />
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Button
              onClick={onGetStarted}
              className="bg-[#5865f2] hover:bg-[#4752c4] text-white shadow-lg hover:shadow-xl transition-all duration-200"
            >
              Get Started
            </Button>
          </motion.div>
        </div>
      </nav>
    </motion.header>
  )
}
