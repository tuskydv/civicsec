"use client"

import { motion } from "framer-motion"
import { Zap } from "lucide-react"

export function Footer() {
  const footerSections = [
    {
      title: "Product",
      links: ["Features", "Pricing", "API Docs", "Integrations"],
    },
    {
      title: "Company",
      links: ["About", "Careers", "Press", "Contact"],
    },
    {
      title: "Resources",
      links: ["Documentation", "Blog", "Support", "Community"],
    },
  ]

  return (
    <footer className="border-t border-[var(--discord-bg-primary)] px-4 py-16 bg-[var(--discord-bg-secondary)]">
      <div className="mx-auto max-w-7xl">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
            <div className="flex items-center space-x-3 mb-4">
              <div className="relative">
                <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-[#5865f2] to-[#3ba55d] flex items-center justify-center shadow-lg">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#3ba55d] rounded-full border-2 border-[var(--discord-bg-secondary)]" />
              </div>
              <div>
                <span className="text-xl font-bold text-[var(--discord-text-primary)]">CivicTrack</span>
                <div className="text-xs text-[var(--discord-text-secondary)]">AI + Blockchain</div>
              </div>
            </div>
            <p className="text-[var(--discord-text-secondary)] mb-4">
              Revolutionizing urban governance through AI-powered civic engagement and blockchain transparency. 🚀
            </p>
            <div className="flex space-x-4">
              {[
                { letter: "𝕏", color: "from-[#5865f2] to-[#4752c4]" },
                { letter: "in", color: "from-[#3ba55d] to-[#2d7d32]" },
                { letter: "G", color: "from-[#faa81a] to-[#e8890b]" },
              ].map((social, index) => (
                <motion.div
                  key={index}
                  className={`w-8 h-8 bg-gradient-to-r ${social.color} rounded-lg flex items-center justify-center cursor-pointer`}
                  whileHover={{ scale: 1.2 }}
                  transition={{ type: "spring", stiffness: 500, damping: 15 }}
                >
                  <span className="text-white text-sm font-bold">{social.letter}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {footerSections.map((section, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: (index + 1) * 0.05, duration: 0.4 }}
            >
              <h3 className="text-[var(--discord-text-primary)] font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link, linkIndex) => (
                  <motion.li key={linkIndex}>
                    <motion.a
                      href="#"
                      className="text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] transition-all duration-200"
                      whileHover={{ x: 5 }}
                    >
                      {link}
                    </motion.a>
                  </motion.li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="border-t border-[var(--discord-bg-primary)] pt-8 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.4 }}
        >
          <p className="text-[var(--discord-text-secondary)]">
            © 2024 CivicTrack. All rights reserved.{" "}
            <span className="bg-gradient-to-r from-[#5865f2] to-[#3ba55d] bg-clip-text text-transparent">
              Building the future of Indian governance. 🇮🇳
            </span>
          </p>
        </motion.div>
      </div>
    </footer>
  )
}
