import { action } from '@uibakery/data';

function loadIssueById() {
  return action('loadIssueById', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      SELECT 
        i.id,
        i.user_id,
        i.title,
        i.description,
        i.category_id,
        c.name as category_name,
        i.latitude as lat,
        i.longitude as lng,
        i.address,
        i.status,
        i.is_anonymous,
        i.is_hidden,
        i.created_at,
        i.updated_at,
        COALESCE(f.flag_count, 0) as flag_count
      FROM issues i
      INNER JOIN categories c ON i.category_id = c.id
      LEFT JOIN (
        SELECT issue_id, COUNT(*) as flag_count
        FROM issue_flags
        GROUP BY issue_id
      ) f ON i.id = f.issue_id
      WHERE i.id = {{params.issueId}};
    `,
  });
}

export default loadIssueById;
