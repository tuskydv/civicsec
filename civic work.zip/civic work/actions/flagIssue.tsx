import { action } from '@uibakery/data';

function flagIssue() {
  return action('flagIssue', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      INSERT INTO issue_flags (issue_id, user_id, reason)
      VALUES ({{params.issueId}}, {{params.userId}}, {{params.reason}})
      ON CONFLICT (issue_id, user_id) DO NOTHING;
    `,
  });
}

export default flagIssue;
