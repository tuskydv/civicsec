import { action } from '@uibakery/data';

function createIssue() {
  return action('createIssue', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      INSERT INTO issues (
        user_id, 
        title, 
        description, 
        category_id, 
        latitude, 
        longitude, 
        address, 
        is_anonymous
      )
      VALUES (
        {{params.userId}},
        {{params.title}},
        {{params.description}},
        {{params.categoryId}},
        {{params.lat}},
        {{params.lng}},
        {{params.address}},
        {{params.isAnonymous}}
      )
      RETURNING id;
    `,
  });
}

export default createIssue;
