"use client"

import { motion, AnimatePresence } from "framer-motion"
import { X, LogIn, UserPlus, Shield } from "lucide-react"
import { useRouter } from "next/navigation"

interface GetStartedModalProps {
  isOpen: boolean
  onClose: () => void
}

export function GetStartedModal({ isOpen, onClose }: GetStartedModalProps) {
  const router = useRouter()

  const options = [
    {
      title: "Citizen Sign In",
      description: "Already have an account? Sign in to access your dashboard and continue reporting issues",
      icon: LogIn,
      color: "bg-[#5865f2]",
      href: "/login",
    },
    {
      title: "Register as Citizen",
      description: "New to CivicSense? Create your citizen account to start reporting issues and earning rewards",
      icon: UserPlus,
      color: "bg-[#3ba55d]",
      href: "/register",
    },
    {
      title: "Admin Login",
      description: "Municipal admin access to the management dashboard and administrative tools",
      icon: Shield,
      color: "bg-[#5865f2]",
      href: "/admin/login",
    },
  ]

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="bg-[var(--discord-bg-secondary)] rounded-2xl p-8 max-w-md w-full border border-[var(--discord-bg-primary)]"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-2xl font-bold text-[var(--discord-text-primary)] mb-2">
                  Get Started with <span className="text-[#5865f2]">CivicSense</span>
                </h2>
                <p className="text-[var(--discord-text-secondary)]">Choose your access level to begin your journey</p>
              </div>
              <button
                onClick={onClose}
                className="text-[var(--discord-text-secondary)] hover:text-[var(--discord-text-primary)] transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              {options.map((option, index) => (
                <motion.button
                  key={option.title}
                  className="w-full flex items-center gap-4 p-4 rounded-xl bg-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-tertiary)] transition-all duration-200 group"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    router.push(option.href)
                    onClose()
                  }}
                >
                  <div className={`${option.color} p-3 rounded-xl`}>
                    <option.icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 text-left">
                    <h3 className="font-semibold text-[var(--discord-text-primary)] mb-1">{option.title}</h3>
                    <p className="text-sm text-[var(--discord-text-secondary)]">{option.description}</p>
                  </div>
                  <div className="text-[var(--discord-text-secondary)] group-hover:text-[var(--discord-text-primary)] transition-colors">
                    →
                  </div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
