"use client"

import { motion } from "framer-motion"
import { Moon, Sun, Palette } from "lucide-react"
import { useTheme } from "@/components/theme-provider"
import { useState } from "react"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [isOpen, setIsOpen] = useState(false)

  const themes = [
    { id: "discord-dark", name: "Discord Dark", icon: Moon },
    { id: "discord-light", name: "Discord Light", icon: Sun },
  ]

  return (
    <div className="relative">
      <motion.button
        onClick={() => setIsOpen(!isOpen)}
        className="p-2 rounded-lg bg-[var(--discord-bg-primary)] hover:bg-[var(--discord-bg-tertiary)] transition-colors"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Palette className="w-5 h-5 text-[var(--discord-text-secondary)]" />
      </motion.button>

      {isOpen && (
        <motion.div
          className="absolute top-12 right-0 bg-[var(--discord-bg-secondary)] border border-[var(--discord-bg-primary)] rounded-lg shadow-lg p-2 min-w-[160px] z-50"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
        >
          {themes.map((themeOption) => (
            <button
              key={themeOption.id}
              onClick={() => {
                setTheme(themeOption.id as any)
                setIsOpen(false)
              }}
              className={`w-full flex items-center gap-3 p-2 rounded-md hover:bg-[var(--discord-bg-primary)] transition-colors ${
                theme === themeOption.id ? "bg-[#5865f2] text-white" : "text-[var(--discord-text-primary)]"
              }`}
            >
              <themeOption.icon className="w-4 h-4" />
              <span className="text-sm">{themeOption.name}</span>
            </button>
          ))}
        </motion.div>
      )}
    </div>
  )
}
