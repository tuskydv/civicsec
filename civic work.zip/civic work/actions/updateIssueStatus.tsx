import { action } from '@uibakery/data';

function updateIssueStatus() {
  return action('updateIssueStatus', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      UPDATE issues 
      SET status = {{params.status}}, updated_at = CURRENT_TIMESTAMP
      WHERE id = {{params.issueId}};
    `,
  });
}

export default updateIssueStatus;
