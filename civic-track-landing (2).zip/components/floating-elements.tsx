"use client"

import { motion } from "framer-motion"
import { useTheme } from "@/hooks/use-theme"

export function FloatingElements() {
  const { theme } = useTheme()

  return (
    <div className="fixed inset-0 pointer-events-none z-0">
      {/* Fast Floating 3D Cubes */}
      <motion.div
        className={`absolute top-20 left-10 w-8 h-8 rounded-lg ${
          theme === "dark"
            ? "bg-gradient-to-r from-cyan-400 to-purple-500 opacity-30"
            : "bg-gradient-to-r from-blue-400 to-purple-500 opacity-20"
        }`}
        animate={{
          y: [0, -30, 0],
          rotateX: [0, 360],
          rotateY: [0, 180],
          scale: [1, 1.2, 1],
        }}
        transition={{
          duration: 2,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
        style={{
          transformStyle: "preserve-3d",
        }}
      />

      <motion.div
        className={`absolute top-40 right-20 w-12 h-12 rounded-full ${
          theme === "dark"
            ? "bg-gradient-to-r from-purple-400 to-pink-500 opacity-25"
            : "bg-gradient-to-r from-purple-400 to-pink-400 opacity-15"
        }`}
        animate={{
          y: [0, 40, 0],
          x: [0, -15, 0],
          scale: [1, 1.3, 1],
          rotate: [0, 360],
        }}
        transition={{
          duration: 3,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />

      <motion.div
        className={`absolute bottom-40 left-1/4 w-6 h-6 rounded-lg ${
          theme === "dark"
            ? "bg-gradient-to-r from-emerald-400 to-cyan-400 opacity-35"
            : "bg-gradient-to-r from-emerald-400 to-blue-400 opacity-25"
        }`}
        animate={{
          rotate: [0, 360],
          y: [0, -25, 0],
          rotateX: [0, 180, 360],
        }}
        transition={{
          duration: 1.5,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
      />

      {/* Subtle floating particles */}
      {Array.from({ length: 15 }).map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 bg-[#5865f2]/30 rounded-full"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -100, 0],
            opacity: [0.3, 0.8, 0.3],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 3 + Math.random() * 4,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 2,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Fast Floating Particles */}
      {Array.from({ length: 25 }).map((_, i) => (
        <motion.div
          key={i}
          className={`absolute w-1 h-1 rounded-full ${
            theme === "dark"
              ? "bg-gradient-to-r from-cyan-400 to-purple-400 opacity-40"
              : "bg-gradient-to-r from-blue-400 to-purple-400 opacity-30"
          }`}
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
          }}
          animate={{
            y: [0, -150, 0],
            opacity: theme === "dark" ? [0.4, 1, 0.4] : [0.3, 0.8, 0.3],
            scale: [1, 1.5, 1],
          }}
          transition={{
            duration: 1.5 + Math.random() * 2,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 1,
            ease: "easeInOut",
          }}
        />
      ))}

      {/* Neon Orbs */}
      <motion.div
        className={`absolute top-1/3 right-1/3 w-20 h-20 rounded-full blur-xl ${
          theme === "dark"
            ? "bg-gradient-to-r from-orange-400 to-red-500 opacity-20"
            : "bg-gradient-to-r from-orange-300 to-red-400 opacity-15"
        }`}
        animate={{
          scale: [1, 1.5, 1],
          rotate: [0, 180, 360],
          opacity: theme === "dark" ? [0.2, 0.4, 0.2] : [0.15, 0.3, 0.15],
        }}
        transition={{
          duration: 2.5,
          repeat: Number.POSITIVE_INFINITY,
          ease: "easeInOut",
        }}
      />
    </div>
  )
}
