export interface User {
  id: number;
  email?: string;
  is_admin: boolean;
  is_banned: boolean;
  created_at: string;
}

export interface Category {
  id: number;
  name: string;
  description?: string;
}

export interface Issue {
  id: number;
  user_id?: number;
  title: string;
  description: string;
  category_id: number;
  category_name?: string;
  location: {
    lat: number;
    lng: number;
  };
  address?: string;
  status: 'Reported' | 'In Progress' | 'Resolved';
  is_anonymous: boolean;
  is_hidden: boolean;
  created_at: string;
  updated_at: string;
  photos?: IssuePhoto[];
  flag_count?: number;
}

export interface IssuePhoto {
  id: number;
  issue_id: number;
  photo_url: string;
  file_size?: number;
  created_at: string;
}

export interface IssueStatusLog {
  id: number;
  issue_id: number;
  status: string;
  notes?: string;
  changed_by?: number;
  timestamp: string;
}

export interface IssueFlag {
  id: number;
  issue_id: number;
  user_id?: number;
  reason: string;
  timestamp: string;
}

export interface Location {
  lat: number;
  lng: number;
}

export interface FilterOptions {
  status?: string;
  category?: number;
  radius?: number;
}
