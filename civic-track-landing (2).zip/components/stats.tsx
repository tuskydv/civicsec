"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"

export function Stats() {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  const stats = [
    { number: "1.2K+", label: "Issues Resolved", color: "from-[#3ba55d] to-[#2d7d32]" },
    { number: "98%", label: "AI Accuracy", color: "from-[#5865f2] to-[#4752c4]" },
    { number: "5.8K", label: "Active Citizens", color: "from-[#faa81a] to-[#e8890b]" },
    { number: "150K", label: "CivicCoins Earned", color: "from-[#ed4245] to-[#c23616]" },
  ]

  return (
    <section className="px-4 py-16" ref={ref}>
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <motion.div
              key={index}
              className="text-center relative"
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{
                delay: index * 0.1,
                duration: 0.5,
                type: "spring",
                stiffness: 200,
              }}
              whileHover={{ scale: 1.05 }}
            >
              <motion.div
                className={`text-4xl lg:text-5xl font-bold bg-gradient-to-r ${stat.color} bg-clip-text text-transparent mb-2 relative z-10`}
              >
                {stat.number}
              </motion.div>
              <div className="text-sm lg:text-base relative z-10 font-medium text-[var(--discord-text-secondary)]">
                {stat.label}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
