// Admin dashboard for managing civic issues and viewing analytics
import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLoadAction, useMutateAction } from '@uibakery/data';
import { Shield, Flag, BarChart3, Users, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import loadIssuesAction from '@/actions/loadIssues';
import loadCategoriesAction from '@/actions/loadCategories';
import updateIssueStatusAction from '@/actions/updateIssueStatus';
import type { Issue, Category } from '@/types';

interface AdminDashboardProps {
  onIssueSelect?: (issue: Issue) => void;
}

export function AdminDashboard({ onIssueSelect }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  const [issues, issuesLoading] = useLoadAction(loadIssuesAction, [], {
    userLat: 0,
    userLng: 0,
    radiusMeters: 50000, // 50km radius for admin view
    status: '',
    categoryId: 0,
  });

  const [categories] = useLoadAction(loadCategoriesAction, []);
  const [updateStatus, isUpdating] = useMutateAction(updateIssueStatusAction);

  // Calculate statistics
  const stats = {
    total: issues.length,
    reported: issues.filter((issue: Issue) => issue.status === 'Reported').length,
    inProgress: issues.filter((issue: Issue) => issue.status === 'In Progress').length,
    resolved: issues.filter((issue: Issue) => issue.status === 'Resolved').length,
    flagged: issues.filter((issue: Issue) => issue.flag_count && issue.flag_count > 0).length,
  };

  const flaggedIssues = issues.filter((issue: Issue) => issue.flag_count && issue.flag_count > 0);
  const recentIssues = issues.slice(0, 10);

  const getCategoryStats = () => {
    return categories.map((category: Category) => {
      const categoryIssues = issues.filter((issue: Issue) => issue.category_id === category.id);
      return {
        ...category,
        count: categoryIssues.length,
        reported: categoryIssues.filter(issue => issue.status === 'Reported').length,
        inProgress: categoryIssues.filter(issue => issue.status === 'In Progress').length,
        resolved: categoryIssues.filter(issue => issue.status === 'Resolved').length,
      };
    });
  };

  const handleQuickStatusUpdate = async (issueId: number, newStatus: string) => {
    try {
      await updateStatus({ issueId, status: newStatus });
      console.log('Issue status updated successfully');
    } catch (error) {
      console.error('Failed to update issue status:', error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (issuesLoading) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">Loading admin dashboard...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Shield className="h-6 w-6 text-blue-600" />
        <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      </div>

      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Issues</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Reported</p>
                <p className="text-2xl font-bold text-red-600">{stats.reported}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">In Progress</p>
                <p className="text-2xl font-bold text-yellow-600">{stats.inProgress}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resolved</p>
                <p className="text-2xl font-bold text-green-600">{stats.resolved}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Flagged</p>
                <p className="text-2xl font-bold text-orange-600">{stats.flagged}</p>
              </div>
              <Flag className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="flagged">Flagged Issues</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Issues</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentIssues.map((issue: Issue) => (
                  <div key={issue.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-medium">{issue.title}</h4>
                        <Badge variant="outline">{issue.category_name}</Badge>
                        <Badge 
                          className={
                            issue.status === 'Reported' ? 'bg-red-100 text-red-800' :
                            issue.status === 'In Progress' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-green-100 text-green-800'
                          }
                        >
                          {issue.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600 truncate">{issue.description}</p>
                      <p className="text-xs text-gray-500 mt-1">{formatDate(issue.created_at)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {issue.status === 'Reported' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleQuickStatusUpdate(issue.id, 'In Progress')}
                          disabled={isUpdating}
                        >
                          Start Work
                        </Button>
                      )}
                      {issue.status === 'In Progress' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleQuickStatusUpdate(issue.id, 'Resolved')}
                          disabled={isUpdating}
                        >
                          Mark Resolved
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => onIssueSelect?.(issue)}
                      >
                        View
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flagged" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Flag className="h-5 w-5 text-orange-600" />
                Flagged Issues ({stats.flagged})
              </CardTitle>
            </CardHeader>
            <CardContent>
              {flaggedIssues.length === 0 ? (
                <p className="text-gray-500 text-center py-8">No flagged issues to review.</p>
              ) : (
                <div className="space-y-3">
                  {flaggedIssues.map((issue: Issue) => (
                    <div key={issue.id} className="p-4 border border-orange-200 rounded-lg bg-orange-50">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h4 className="font-medium">{issue.title}</h4>
                            <Badge variant="destructive" className="flex items-center gap-1">
                              <Flag className="h-3 w-3" />
                              {issue.flag_count} flags
                            </Badge>
                            <Badge variant="outline">{issue.category_name}</Badge>
                          </div>
                          <p className="text-sm text-gray-700 mb-2">{issue.description}</p>
                          <p className="text-xs text-gray-500">Reported: {formatDate(issue.created_at)}</p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => onIssueSelect?.(issue)}
                          >
                            Review
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Issues by Category</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {getCategoryStats().map((category) => (
                  <div key={category.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{category.name}</h4>
                      <Badge variant="outline">{category.count} total</Badge>
                    </div>
                    <p className="text-sm text-gray-600 mb-3">{category.description}</p>
                    <div className="flex gap-4 text-sm">
                      <span className="text-red-600">{category.reported} reported</span>
                      <span className="text-yellow-600">{category.inProgress} in progress</span>
                      <span className="text-green-600">{category.resolved} resolved</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                      <div 
                        className="bg-green-600 h-2 rounded-full" 
                        style={{ width: `${category.count > 0 ? (category.resolved / category.count) * 100 : 0}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
