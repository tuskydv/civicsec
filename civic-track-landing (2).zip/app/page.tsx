"use client"

import { useState } from "react"
import { Hero } from "@/components/hero"
import { Features } from "@/components/features"
import { Stats } from "@/components/stats"
import { Vision } from "@/components/vision"
import { CTA } from "@/components/cta"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { FloatingElements } from "@/components/floating-elements"
import { GetStartedModal } from "@/components/get-started-modal"

export default function Home() {
  const [showGetStarted, setShowGetStarted] = useState(false)

  return (
    <div className="min-h-screen bg-[var(--discord-bg-tertiary)] overflow-x-hidden transition-all duration-300">
      <FloatingElements />
      <Header onGetStarted={() => setShowGetStarted(true)} />
      <Hero onGetStarted={() => setShowGetStarted(true)} />
      <Stats />
      <Features />
      <Vision />
      <CTA onGetStarted={() => setShowGetStarted(true)} />
      <Footer />
      <GetStartedModal isOpen={showGetStarted} onClose={() => setShowGetStarted(false)} />
    </div>
  )
}
