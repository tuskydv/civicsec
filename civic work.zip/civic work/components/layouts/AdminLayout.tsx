// Advanced admin layout with animated sidebar and comprehensive navigation
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAppContext } from '@/app/app';
import { 
  Shield, BarChart3, Users, Settings, FileText, AlertTriangle, Home, 
  Menu, X, Bell, Search, LogOut, ChevronDown, Activity, Zap, Filter
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { useLoadAction } from '@uibakery/data';
import loadIssuesAction from '@/actions/loadIssues';

export function AdminLayout() {
  const { setIsAdmin } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Load data for dashboard stats
  const [issues] = useLoadAction(loadIssuesAction, [], {
    userLat: 0,
    userLng: 0,
    radiusMeters: 50000,
    status: '',
    categoryId: 0,
  });

  const stats = {
    total: issues.length,
    reported: issues.filter((issue: any) => issue.status === 'Reported').length,
    inProgress: issues.filter((issue: any) => issue.status === 'In Progress').length,
    flagged: issues.filter((issue: any) => issue.flag_count && issue.flag_count > 0).length,
  };

  const handleExitAdmin = () => {
    setIsAdmin(false);
    navigate('/');
  };

  const navigationItems = [
    {
      path: '/admin/dashboard',
      label: 'Dashboard',
      icon: BarChart3,
      description: 'Overview & Analytics',
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      path: '/admin/issues',
      label: 'Issue Management',
      icon: AlertTriangle,
      description: 'Manage all issues',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      badge: stats.reported
    },
    {
      path: '/admin/analytics',
      label: 'Analytics',
      icon: Activity,
      description: 'Advanced reporting',
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      path: '/admin/users',
      label: 'User Management',
      icon: Users,
      description: 'Manage community',
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      path: '/admin/reports',
      label: 'Reports',
      icon: FileText,
      description: 'Generated reports',
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50'
    },
    {
      path: '/admin/settings',
      label: 'Settings',
      icon: Settings,
      description: 'System configuration',
      color: 'text-gray-600',
      bgColor: 'bg-gray-50'
    },
  ];

  const sidebarVariants = {
    open: {
      x: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 40
      }
    },
    closed: {
      x: -320,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 40
      }
    }
  };

  const Sidebar = ({ isMobile = false }: { isMobile?: boolean }) => (
    <motion.div
      variants={!isMobile ? sidebarVariants : undefined}
      initial={!isMobile ? "closed" : undefined}
      animate={!isMobile ? "open" : undefined}
      className={`${isMobile ? 'w-full' : 'w-80'} h-full bg-white border-r border-gray-200 flex flex-col overflow-hidden`}
    >
      {/* Sidebar Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative">
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center"
            >
              <Shield className="h-5 w-5 text-white" />
            </motion.div>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"
            />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">Admin Panel</h2>
            <p className="text-xs text-gray-500">CivicConnect Management</p>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-3">
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-red-50 to-red-100 p-3 rounded-lg"
          >
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <div>
                <p className="text-xs text-red-600 font-medium">New Issues</p>
                <p className="text-lg font-bold text-red-700">{stats.reported}</p>
              </div>
            </div>
          </motion.div>
          <motion.div 
            whileHover={{ scale: 1.02 }}
            className="bg-gradient-to-br from-blue-50 to-blue-100 p-3 rounded-lg"
          >
            <div className="flex items-center gap-2">
              <Activity className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-xs text-blue-600 font-medium">Total</p>
                <p className="text-lg font-bold text-blue-700">{stats.total}</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Search */}
      <div className="p-4 border-b border-gray-200">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search admin panel..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 bg-gray-50 border-gray-200"
          />
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto p-4">
        <div className="space-y-2">
          {navigationItems.map((item, index) => (
            <motion.div
              key={item.path}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link to={item.path} onClick={() => isMobile && setIsSidebarOpen(false)}>
                <motion.div
                  whileHover={{ x: 4, scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`flex items-center gap-4 p-4 rounded-xl transition-all duration-200 ${
                    location.pathname === item.path
                      ? `${item.bgColor} ${item.color} shadow-md border border-opacity-20`
                      : 'hover:bg-gray-50 text-gray-700'
                  }`}
                >
                  <div className={`p-2 rounded-lg ${location.pathname === item.path ? 'bg-white bg-opacity-70' : 'bg-gray-100'}`}>
                    <item.icon className={`h-5 w-5 ${location.pathname === item.path ? item.color : 'text-gray-600'}`} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{item.label}</span>
                      {item.badge && item.badge > 0 && (
                        <Badge variant="destructive" className="text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs opacity-70">{item.description}</p>
                  </div>
                  {location.pathname === item.path && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="w-1 h-8 bg-gradient-to-b from-transparent via-current to-transparent rounded-full opacity-50"
                    />
                  )}
                </motion.div>
              </Link>
            </motion.div>
          ))}
        </div>
      </nav>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-gray-200">
        <div className="flex items-center gap-3 mb-3">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-gradient-to-br from-blue-600 to-indigo-600 text-white text-sm">
              AD
            </AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <p className="text-sm font-medium text-gray-900">Administrator</p>
            <p className="text-xs text-gray-500">System Admin</p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleExitAdmin}
          className="w-full flex items-center gap-2 text-gray-600 hover:text-gray-900"
        >
          <Home className="h-4 w-4" />
          Exit Admin
        </Button>
      </div>
    </motion.div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block fixed inset-y-0 left-0 z-50">
        <Sidebar />
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
        <SheetContent side="left" className="p-0 w-80">
          <Sidebar isMobile />
        </SheetContent>
      </Sheet>

      {/* Main Content */}
      <div className="flex-1 lg:ml-80">
        {/* Top Bar */}
        <motion.header
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-gray-200"
        >
          <div className="flex items-center justify-between px-6 py-4">
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsSidebarOpen(true)}
                className="lg:hidden"
              >
                <Menu className="h-4 w-4" />
              </Button>
              
              <div>
                <h1 className="text-xl font-semibold text-gray-900">
                  {navigationItems.find(item => item.path === location.pathname)?.label || 'Admin Panel'}
                </h1>
                <p className="text-sm text-gray-500">
                  {navigationItems.find(item => item.path === location.pathname)?.description}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Notifications */}
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button variant="outline" size="sm" className="relative">
                  <Bell className="h-4 w-4" />
                  {stats.flagged > 0 && (
                    <motion.span
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ duration: 2, repeat: Infinity }}
                      className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"
                    />
                  )}
                </Button>
              </motion.div>

              {/* Quick Actions */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="flex items-center gap-2">
                    <Zap className="h-4 w-4" />
                    <span className="hidden sm:inline">Quick Actions</span>
                    <ChevronDown className="h-3 w-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => navigate('/admin/issues')}>
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    View New Issues
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate('/admin/analytics')}>
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Generate Report
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleExitAdmin}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Exit Admin Panel
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </motion.header>

        {/* Page Content */}
        <main className="p-6">
          <AnimatePresence mode="wait">
            <Outlet />
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
