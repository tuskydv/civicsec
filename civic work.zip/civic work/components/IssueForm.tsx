// Form component for reporting new civic issues
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLoadAction, useMutateAction } from '@uibakery/data';
import { MapPin, Camera, AlertCircle } from 'lucide-react';
import loadCategoriesAction from '@/actions/loadCategories';
import createIssueAction from '@/actions/createIssue';
import { getCurrentLocation } from '@/utils/location';
import type { Category, Location } from '@/types';

const issueSchema = z.object({
  title: z.string().min(5, 'Title must be at least 5 characters').max(100, 'Title must be under 100 characters'),
  description: z.string().min(10, 'Description must be at least 10 characters').max(500, 'Description must be under 500 characters'),
  categoryId: z.string().min(1, 'Please select a category'),
  address: z.string().default(''),
  isAnonymous: z.boolean().default(false),
});

type IssueFormData = z.infer<typeof issueSchema>;

interface IssueFormProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

export function IssueForm({ onSuccess, onCancel }: IssueFormProps) {
  const [location, setLocation] = useState<Location | null>(null);
  const [locationError, setLocationError] = useState<string>('');
  const [isGettingLocation, setIsGettingLocation] = useState(false);

  const [categories, categoriesLoading] = useLoadAction(loadCategoriesAction, []);
  const [createIssue, isCreating, createError] = useMutateAction(createIssueAction);

  const form = useForm({
    resolver: zodResolver(issueSchema),
    defaultValues: {
      title: '',
      description: '',
      categoryId: '',
      address: '',
      isAnonymous: false,
    },
  });

  const handleGetLocation = async () => {
    setIsGettingLocation(true);
    setLocationError('');
    
    try {
      const currentLocation = await getCurrentLocation();
      setLocation(currentLocation);
      console.log('Location obtained:', currentLocation);
    } catch (error) {
      setLocationError('Failed to get your location. Please enter your address manually.');
      console.error('Location error:', error);
    } finally {
      setIsGettingLocation(false);
    }
  };

  const onSubmit = async (data: IssueFormData) => {
    if (!location) {
      setLocationError('Location is required. Please get your location or enter an address.');
      return;
    }

    try {
      await createIssue({
        userId: null, // Anonymous for now
        title: data.title,
        description: data.description,
        categoryId: parseInt(data.categoryId),
        lat: location.lat,
        lng: location.lng,
        address: data.address || '',
        isAnonymous: data.isAnonymous,
      });

      console.log('Issue created successfully');
      onSuccess?.();
    } catch (error) {
      console.error('Failed to create issue:', error);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertCircle className="h-5 w-5 text-blue-600" />
          Report a Civic Issue
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Issue Title</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Brief description of the issue (e.g., 'Pothole on Main Street')" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Provide a clear, concise title (5-100 characters)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Detailed Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Provide more details about the issue, its severity, and any safety concerns..."
                      className="min-h-[100px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Detailed description (10-500 characters)
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="categoryId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select issue category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {categories.map((category: Category) => (
                        <SelectItem key={category.id} value={category.id.toString()}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose the category that best describes your issue
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Location</label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleGetLocation}
                  disabled={isGettingLocation}
                  className="flex items-center gap-2"
                >
                  <MapPin className="h-4 w-4" />
                  {isGettingLocation ? 'Getting Location...' : 'Get My Location'}
                </Button>
              </div>
              
              {location && (
                <div className="p-3 bg-green-50 border border-green-200 rounded-md">
                  <p className="text-sm text-green-800">
                    Location captured: {location.lat.toFixed(6)}, {location.lng.toFixed(6)}
                  </p>
                </div>
              )}

              {locationError && (
                <Alert variant="destructive">
                  <AlertDescription>{locationError}</AlertDescription>
                </Alert>
              )}

              <FormField
                control={form.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormControl>
                      <Input 
                        placeholder="Enter address or landmark (optional)" 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Provide additional location context if needed
                    </FormDescription>
                  </FormItem>
                )}
              />
            </div>

            {createError && (
              <Alert variant="destructive">
                <AlertDescription>
                  Failed to submit issue. Please try again.
                </AlertDescription>
              </Alert>
            )}

            <div className="flex gap-3 pt-4">
              <Button
                type="submit"
                disabled={isCreating || !location}
                className="flex-1"
              >
                {isCreating ? 'Submitting...' : 'Submit Issue'}
              </Button>
              {onCancel && (
                <Button type="button" variant="outline" onClick={onCancel}>
                  Cancel
                </Button>
              )}
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
