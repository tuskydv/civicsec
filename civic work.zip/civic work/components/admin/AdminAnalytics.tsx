// Advanced analytics dashboard with detailed reporting and visualizations
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useLoadAction } from '@uibakery/data';
import { 
  BarChart3, TrendingUp, Download, Calendar as CalendarIcon, 
  Activity, Users, MapPin, Clock, Target, Zap
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import loadIssuesAction from '@/actions/loadIssues';
import loadCategoriesAction from '@/actions/loadCategories';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';

const COLORS = ['#3B82F6', '#EF4444', '#F59E0B', '#10B981', '#8B5CF6', '#F97316', '#06B6D4', '#84CC16'];

export function AdminAnalytics() {
  const [dateRange, setDateRange] = useState<Date | undefined>(new Date());
  const [timeRange, setTimeRange] = useState('30d');

  const [issues] = useLoadAction(loadIssuesAction, [], {
    userLat: 0,
    userLng: 0,
    radiusMeters: 100000,
    status: '',
    categoryId: 0,
  });

  const [categories] = useLoadAction(loadCategoriesAction, []);

  // Generate time series data
  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
  const timeSeriesData = Array.from({ length: days }, (_, i) => {
    const date = subDays(new Date(), days - 1 - i);
    const dayStart = startOfDay(date);
    const dayEnd = endOfDay(date);
    
    const dayIssues = issues.filter((issue: any) => {
      const issueDate = new Date(issue.created_at);
      return issueDate >= dayStart && issueDate <= dayEnd;
    });

    return {
      date: format(date, 'MMM dd'),
      fullDate: format(date, 'yyyy-MM-dd'),
      total: dayIssues.length,
      reported: dayIssues.filter((issue: any) => issue.status === 'Reported').length,
      inProgress: dayIssues.filter((issue: any) => issue.status === 'In Progress').length,
      resolved: dayIssues.filter((issue: any) => issue.status === 'Resolved').length,
    };
  });

  // Category performance data
  const categoryData = categories.map((category: any) => {
    const categoryIssues = issues.filter((issue: any) => issue.category_id === category.id);
    const resolved = categoryIssues.filter((issue: any) => issue.status === 'Resolved').length;
    const resolutionRate = categoryIssues.length > 0 ? (resolved / categoryIssues.length) * 100 : 0;

    return {
      name: category.name,
      total: categoryIssues.length,
      resolved,
      resolutionRate: Math.round(resolutionRate),
      avgResolutionTime: Math.floor(Math.random() * 7) + 1, // Mock data
    };
  });

  // Status distribution
  const statusData = [
    { name: 'Reported', value: issues.filter((issue: any) => issue.status === 'Reported').length, color: '#EF4444' },
    { name: 'In Progress', value: issues.filter((issue: any) => issue.status === 'In Progress').length, color: '#F59E0B' },
    { name: 'Resolved', value: issues.filter((issue: any) => issue.status === 'Resolved').length, color: '#10B981' },
  ];

  // Response time analysis
  const responseTimeData = Array.from({ length: 7 }, (_, i) => ({
    day: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'][i],
    avgResponse: Math.floor(Math.random() * 24) + 1,
    target: 6,
  }));

  const handleExport = () => {
    console.log('Exporting analytics data...');
  };

  const analyticsCards = [
    {
      title: 'Resolution Rate',
      value: `${Math.round((issues.filter((issue: any) => issue.status === 'Resolved').length / issues.length) * 100) || 0}%`,
      change: '+5.2%',
      changeColor: 'text-green-600',
      icon: Target,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      title: 'Avg Response Time',
      value: '4.2h',
      change: '-12m',
      changeColor: 'text-green-600',
      icon: Clock,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      title: 'Active Issues',
      value: issues.filter((issue: any) => issue.status !== 'Resolved').length.toString(),
      change: '+3',
      changeColor: 'text-orange-600',
      icon: Activity,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    },
    {
      title: 'User Engagement',
      value: '87%',
      change: '+2.1%',
      changeColor: 'text-green-600',
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h1>
          <p className="text-gray-600">Detailed insights and performance metrics</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExport} className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </motion.div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {analyticsCards.map((card, index) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">{card.title}</p>
                    <p className="text-2xl font-bold text-gray-900 mt-1">{card.value}</p>
                    <p className={`text-sm ${card.changeColor} mt-1`}>{card.change} from last period</p>
                  </div>
                  <div className={`p-3 rounded-full ${card.bgColor}`}>
                    <card.icon className={`h-6 w-6 ${card.color}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Issue Trends */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                Issue Trends
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={timeSeriesData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="total" stroke="#3B82F6" strokeWidth={2} />
                  <Line type="monotone" dataKey="resolved" stroke="#10B981" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Category Performance */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                Category Performance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={categoryData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="resolutionRate" fill="#10B981" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Status Distribution */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-purple-600" />
                Status Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, value }: any) => `${name}: ${value}`}
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Response Time Trends */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.7 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-orange-600" />
                Response Time Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={responseTimeData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="avgResponse" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.3} />
                  <Line type="monotone" dataKey="target" stroke="#EF4444" strokeDasharray="5 5" />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Detailed Category Analysis */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Category Detailed Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categoryData.map((category, index) => (
                <motion.div
                  key={category.name}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.9 + index * 0.1 }}
                  className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <h4 className="font-semibold text-gray-900">{category.name}</h4>
                    <p className="text-sm text-gray-600">{category.total} total issues</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{category.resolutionRate}%</p>
                    <p className="text-xs text-gray-500">Resolution Rate</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-blue-600">{category.avgResolutionTime}d</p>
                    <p className="text-xs text-gray-500">Avg Resolution Time</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-purple-600">{category.resolved}</p>
                    <p className="text-xs text-gray-500">Resolved Issues</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
