import { action } from '@uibakery/data';

function addStatusLog() {
  return action('addStatusLog', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      INSERT INTO issue_status_logs (issue_id, status, notes, changed_by)
      VALUES ({{params.issueId}}, {{params.status}}, {{params.notes}}, {{params.changedBy}});
    `,
  });
}

export default addStatusLog;
