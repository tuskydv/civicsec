import { action } from '@uibakery/data';

function loadCategories() {
  return action('loadCategories', 'SQL', {
    databaseName: '[Sample] Custom App_MAGc1GGWGE',
    query: `
      SELECT id, name, description
      FROM categories
      ORDER BY name;
    `,
  });
}

export default loadCategories;
