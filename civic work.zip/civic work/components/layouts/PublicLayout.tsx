// Public layout with modern navigation and animations
import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { useAppContext } from '@/app/app';
import { MapPin, List, PlusCircle, AlertCircle, Shield, Home, Menu } from 'lucide-react';
import { useState } from 'react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

interface PublicLayoutProps {
  isLoadingLocation: boolean;
  locationError: string;
}

export function PublicLayout({ isLoadingLocation, locationError }: PublicLayoutProps) {
  const { isAdmin, setIsAdmin, userLocation } = useAppContext();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleAdminToggle = () => {
    if (!isAdmin) {
      setIsAdmin(true);
      navigate('/admin');
    } else {
      setIsAdmin(false);
      navigate('/');
    }
  };

  const navItems = [
    { path: '/', label: 'Issues', icon: List },
    { path: '/report', label: 'Report', icon: PlusCircle },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200/50 shadow-sm"
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <motion.div 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-3"
            >
              <Link to="/" className="flex items-center gap-3">
                <div className="relative">
                  <AlertCircle className="h-8 w-8 text-blue-600" />
                  <motion.div
                    className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full"
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                    CivicConnect
                  </h1>
                  <p className="text-xs text-gray-600">Community Issue Tracker</p>
                </div>
              </Link>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <motion.div key={item.path} whileHover={{ y: -2 }} whileTap={{ y: 0 }}>
                  <Link to={item.path}>
                    <Button
                      variant={location.pathname === item.path ? "default" : "ghost"}
                      className="flex items-center gap-2 transition-all duration-200"
                    >
                      <item.icon className="h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                </motion.div>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-3">
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant={isAdmin ? 'default' : 'outline'}
                  size="sm"
                  onClick={handleAdminToggle}
                  className="hidden sm:flex items-center gap-2 transition-all duration-200"
                >
                  <Shield className="h-4 w-4" />
                  {isAdmin ? 'Admin Panel' : 'Admin Access'}
                </Button>
              </motion.div>

              {/* Mobile Menu */}
              <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" size="sm" className="md:hidden">
                    <Menu className="h-4 w-4" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="w-80">
                  <div className="flex flex-col gap-4 mt-8">
                    <div className="border-b pb-4">
                      <h3 className="font-semibold text-lg">Navigation</h3>
                    </div>
                    {navItems.map((item) => (
                      <Link
                        key={item.path}
                        to={item.path}
                        onClick={() => setIsMobileMenuOpen(false)}
                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <item.icon className="h-5 w-5" />
                        <span>{item.label}</span>
                      </Link>
                    ))}
                    <div className="border-t pt-4">
                      <Button
                        variant={isAdmin ? 'default' : 'outline'}
                        onClick={() => {
                          handleAdminToggle();
                          setIsMobileMenuOpen(false);
                        }}
                        className="w-full flex items-center gap-2"
                      >
                        <Shield className="h-4 w-4" />
                        {isAdmin ? 'Admin Panel' : 'Admin Access'}
                      </Button>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Location Status */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2, duration: 0.5 }}
        className="container mx-auto px-4 py-2"
      >
        {isLoadingLocation ? (
          <Alert className="bg-blue-50 border-blue-200">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            >
              <MapPin className="h-4 w-4" />
            </motion.div>
            <AlertDescription>Getting your location...</AlertDescription>
          </Alert>
        ) : userLocation ? (
          <Alert className="bg-green-50 border-green-200">
            <MapPin className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-700">
              <div className="flex items-center gap-2">
                <span>Location found: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}</span>
                <Badge variant="outline" className="text-xs">
                  5km radius
                </Badge>
              </div>
            </AlertDescription>
          </Alert>
        ) : locationError ? (
          <Alert variant="destructive" className="bg-red-50 border-red-200">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{locationError}</AlertDescription>
          </Alert>
        ) : null}
      </motion.div>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-6 max-w-6xl">
        <Outlet />
      </main>

      {/* Floating Action Button for Mobile */}
      {location.pathname === '/' && (
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.5, type: "spring", stiffness: 300, damping: 20 }}
          className="fixed bottom-6 right-6 md:hidden z-40"
        >
          <Link to="/report">
            <motion.div
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full p-4 shadow-lg shadow-blue-500/25"
            >
              <PlusCircle className="h-6 w-6 text-white" />
            </motion.div>
          </Link>
        </motion.div>
      )}
    </div>
  );
}
