"use client"

import { motion } from "framer-motion"
import { useInView } from "framer-motion"
import { useRef } from "react"
import { Button } from "@/components/ui/button"
import { Rocket, Users } from "lucide-react"

interface CTAProps {
  onGetStarted: () => void
}

export function CTA({ onGetStarted }: CTAProps) {
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  return (
    <section className="px-4 py-20" ref={ref}>
      <motion.div
        className="mx-auto max-w-4xl text-center relative"
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ duration: 0.6 }}
      >
        <h2 className="text-4xl lg:text-5xl font-bold text-[var(--discord-text-primary)] mb-6">
          Ready to{" "}
          <span className="bg-gradient-to-r from-[#5865f2] via-[#3ba55d] to-[#faa81a] bg-clip-text text-transparent">
            Transform India?
          </span>
        </h2>

        <p className="text-xl text-[var(--discord-text-secondary)] mb-8 max-w-2xl mx-auto">
          Join the civic revolution. Build smarter cities with AI, blockchain, and community power. The future starts
          now! 🚀
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button size="lg" onClick={onGetStarted} className="bg-[#5865f2] hover:bg-[#4752c4] text-white shadow-lg">
              <Rocket className="mr-2 h-5 w-5" />
              Launch Revolution
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              size="lg"
              variant="outline"
              className="border-2 border-[var(--discord-bg-primary)] text-[var(--discord-text-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent backdrop-blur-sm"
            >
              <Users className="mr-2 h-5 w-5" />
              Partner With Us
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </section>
  )
}
