// Modern CivicConnect app with advanced admin system and routing
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect, createContext, useContext } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { getCurrentLocation } from '@/utils/location';
import type { Issue, Location } from '@/types';

// Context for app state
interface AppContextType {
  isAdmin: boolean;
  setIsAdmin: (value: boolean) => void;
  userLocation: Location | null;
  setUserLocation: (value: Location | null) => void;
  selectedIssue: Issue | null;
  setSelectedIssue: (issue: Issue | null) => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppContext must be used within AppProvider');
  }
  return context;
};

// Lazy load components for better performance
import { PublicLayout } from '@/components/layouts/PublicLayout';
import { AdminLayout } from '@/components/layouts/AdminLayout';
import { IssueList } from '@/components/IssueList';
import { IssueForm } from '@/components/IssueForm';
import { IssueDetail } from '@/components/IssueDetail';
import { AdminDashboard } from '@/components/admin/AdminDashboard';
import { AdminIssues } from '@/components/admin/AdminIssues';
import { AdminAnalytics } from '@/components/admin/AdminAnalytics';
import { AdminUsers } from '@/components/admin/AdminUsers';
import { AdminSettings } from '@/components/admin/AdminSettings';
import { AdminReports } from '@/components/admin/AdminReports';

// Page transition animations
const pageVariants = {
  initial: {
    opacity: 0,
    y: 20,
    scale: 0.95
  },
  in: {
    opacity: 1,
    y: 0,
    scale: 1
  },
  out: {
    opacity: 0,
    y: -20,
    scale: 1.05
  }
};

const pageTransition = {
  type: "tween",
  ease: "anticipate",
  duration: 0.4
};

// Animated page wrapper
const AnimatedPage = ({ children }: { children: React.ReactNode }) => {
  return (
    <motion.div
      initial="initial"
      animate="in"
      exit="out"
      variants={pageVariants}
      transition={pageTransition}
      className="w-full"
    >
      {children}
    </motion.div>
  );
};

function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [userLocation, setUserLocation] = useState<Location | null>(null);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [isLoadingLocation, setIsLoadingLocation] = useState(true);
  const [locationError, setLocationError] = useState<string>('');

  useEffect(() => {
    // Get user location on app load with enhanced error handling
    const getLocation = async () => {
      try {
        const location = await getCurrentLocation();
        setUserLocation(location);
        console.log('User location obtained:', location);
      } catch (error) {
        setLocationError('Unable to get your location. Issues will show without distance filtering.');
        console.error('Location error:', error);
      } finally {
        setIsLoadingLocation(false);
      }
    };

    getLocation();
  }, []);

  const contextValue: AppContextType = {
    isAdmin,
    setIsAdmin,
    userLocation,
    setUserLocation,
    selectedIssue,
    setSelectedIssue
  };

  return (
    <AppContext.Provider value={contextValue}>
      <BrowserRouter>
        <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50">
          <AnimatePresence mode="wait">
            <Routes>
              {/* Public Routes */}
              <Route path="/" element={<PublicLayout isLoadingLocation={isLoadingLocation} locationError={locationError} />}>
                <Route index element={
                  <AnimatedPage>
                    <IssueList />
                  </AnimatedPage>
                } />
                <Route path="report" element={
                  <AnimatedPage>
                    <IssueForm />
                  </AnimatedPage>
                } />
                <Route path="issue/:id" element={
                  <AnimatedPage>
                    <IssueDetail issue={selectedIssue || undefined} />
                  </AnimatedPage>
                } />
              </Route>

              {/* Admin Routes */}
              <Route path="/admin" element={<AdminLayout />}>
                <Route index element={<Navigate to="/admin/dashboard" replace />} />
                <Route path="dashboard" element={
                  <AnimatedPage>
                    <AdminDashboard />
                  </AnimatedPage>
                } />
                <Route path="issues" element={
                  <AnimatedPage>
                    <AdminIssues />
                  </AnimatedPage>
                } />
                <Route path="analytics" element={
                  <AnimatedPage>
                    <AdminAnalytics />
                  </AnimatedPage>
                } />
                <Route path="users" element={
                  <AnimatedPage>
                    <AdminUsers />
                  </AnimatedPage>
                } />
                <Route path="reports" element={
                  <AnimatedPage>
                    <AdminReports />
                  </AnimatedPage>
                } />
                <Route path="settings" element={
                  <AnimatedPage>
                    <AdminSettings />
                  </AnimatedPage>
                } />
              </Route>

              {/* Catch all - redirect to home */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </AnimatePresence>

          <Toaster />
        </div>
      </BrowserRouter>
    </AppContext.Provider>
  );
}

export default App;
