// Component to display list of civic issues with filtering
import { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useLoadAction } from '@uibakery/data';
import { MapPin, Clock, Flag, Eye } from 'lucide-react';
import { formatDistance, calculateDistance } from '@/utils/location';
import loadIssuesAction from '@/actions/loadIssues';
import loadCategoriesAction from '@/actions/loadCategories';
import type { Issue, Category, Location, FilterOptions } from '@/types';

interface IssueListProps {
  userLocation?: Location;
  onIssueSelect?: (issue: Issue) => void;
  onReportNew?: () => void;
}

export function IssueList({ userLocation, onIssueSelect, onReportNew }: IssueListProps) {
  const [filters, setFilters] = useState<FilterOptions>({
    status: 'all',
    category: 0,
    radius: 5000, // 5km in meters
  });

  const [categories] = useLoadAction(loadCategoriesAction, []);
  const [issues, issuesLoading, issuesError, refreshIssues] = useLoadAction(
    loadIssuesAction,
    [],
    {
      userLat: userLocation?.lat || 0,
      userLng: userLocation?.lng || 0,
      radiusMeters: filters.radius,
      status: filters.status === 'all' ? '' : filters.status,
      categoryId: filters.category,
    }
  );

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Reported': return 'bg-red-100 text-red-800 border-red-200';
      case 'In Progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Resolved': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getCategoryName = (categoryId: number) => {
    const category = categories.find((c: Category) => c.id === categoryId);
    return category?.name || 'Unknown';
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Less than an hour ago';
    if (diffInHours < 24) return `${diffInHours} hours ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    if (diffInDays < 7) return `${diffInDays} days ago`;
    return date.toLocaleDateString();
  };

  const handleFilterChange = (key: keyof FilterOptions, value: string | number) => {
    setFilters(prev => ({ ...prev, [key]: value }));
  };

  if (issuesError) {
    return (
      <Alert variant="destructive">
        <AlertDescription>
          Failed to load issues. Please check your connection and try again.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header with filters */}
      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-blue-600" />
              Local Issues
              {userLocation && (
                <Badge variant="outline" className="ml-2">
                  Within {filters.radius / 1000}km
                </Badge>
              )}
            </CardTitle>
            <Button onClick={onReportNew} className="whitespace-nowrap">
              Report Issue
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-3">
            <Select value={filters.status} onValueChange={(value) => handleFilterChange('status', value)}>
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="Reported">Reported</SelectItem>
                <SelectItem value="In Progress">In Progress</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
              </SelectContent>
            </Select>

            <Select 
              value={filters.category?.toString() || ''} 
              onValueChange={(value) => handleFilterChange('category', parseInt(value) || 0)}
            >
              <SelectTrigger className="w-full sm:w-40">
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="0">All Categories</SelectItem>
                {categories.map((category: Category) => (
                  <SelectItem key={category.id} value={category.id.toString()}>
                    {category.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select 
              value={filters.radius?.toString() || '5000'} 
              onValueChange={(value) => handleFilterChange('radius', parseInt(value))}
            >
              <SelectTrigger className="w-full sm:w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1000">1km</SelectItem>
                <SelectItem value="3000">3km</SelectItem>
                <SelectItem value="5000">5km</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Issues list */}
      {issuesLoading ? (
        <div className="text-center py-8 text-gray-500">
          Loading issues...
        </div>
      ) : issues.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500 mb-4">No issues found in your area.</p>
            <Button onClick={onReportNew} variant="outline">
              Be the first to report an issue
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {issues.map((issue: Issue) => {
            const distance = userLocation 
              ? calculateDistance(
                  userLocation.lat,
                  userLocation.lng,
                  issue.location.lat,
                  issue.location.lng
                )
              : null;

            return (
              <Card 
                key={issue.id} 
                className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => onIssueSelect?.(issue)}
              >
                <CardContent className="p-4">
                  <div className="flex justify-between items-start gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className={getStatusColor(issue.status)}>
                          {issue.status}
                        </Badge>
                        <Badge variant="outline">
                          {issue.category_name}
                        </Badge>
                        {issue.flag_count && issue.flag_count > 0 && (
                          <Badge variant="destructive" className="flex items-center gap-1">
                            <Flag className="h-3 w-3" />
                            {issue.flag_count}
                          </Badge>
                        )}
                      </div>
                      
                      <h3 className="font-semibold text-lg mb-1 truncate">
                        {issue.title}
                      </h3>
                      
                      <p className="text-gray-600 text-sm line-clamp-2 mb-2">
                        {issue.description}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {formatTimeAgo(issue.created_at)}
                        </div>
                        {distance && (
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {formatDistance(distance)}
                          </div>
                        )}
                        {issue.address && (
                          <span className="truncate max-w-32">
                            {issue.address}
                          </span>
                        )}
                      </div>
                    </div>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      className="shrink-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        onIssueSelect?.(issue);
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
