// Advanced admin dashboard with real-time analytics and animations
import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useLoadAction, useMutateAction } from '@uibakery/data';
import {
  BarChart3, TrendingUp, Users, AlertTriangle, CheckCircle, Clock,
  Flag, MapPin, Calendar, Activity, Zap, Eye, ArrowUp, ArrowDown
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import loadIssuesAction from '@/actions/loadIssues';
import loadCategoriesAction from '@/actions/loadCategories';
import { format, subDays, startOfDay } from 'date-fns';

const COLORS = ['#3B82F6', '#EF4444', '#F59E0B', '#10B981', '#8B5CF6', '#F97316'];

export function AdminDashboard() {
  const [timeRange, setTimeRange] = useState('7d');
  const [refreshing, setRefreshing] = useState(false);

  const [issues] = useLoadAction(loadIssuesAction, [], {
    userLat: 0,
    userLng: 0,
    radiusMeters: 100000, // 100km for admin view
    status: '',
    categoryId: 0,
  });

  const [categories] = useLoadAction(loadCategoriesAction, []);

  // Calculate comprehensive statistics
  const stats = {
    total: issues.length,
    reported: issues.filter((issue: any) => issue.status === 'Reported').length,
    inProgress: issues.filter((issue: any) => issue.status === 'In Progress').length,
    resolved: issues.filter((issue: any) => issue.status === 'Resolved').length,
    flagged: issues.filter((issue: any) => issue.flag_count && issue.flag_count > 0).length,
    anonymous: issues.filter((issue: any) => issue.is_anonymous).length,
    todayCount: issues.filter((issue: any) => {
      const today = startOfDay(new Date());
      return new Date(issue.created_at) >= today;
    }).length,
  };

  // Calculate trends
  const yesterday = subDays(new Date(), 1);
  const yesterdayCount = issues.filter((issue: any) => {
    const issueDate = new Date(issue.created_at);
    return issueDate >= startOfDay(yesterday) && issueDate < startOfDay(new Date());
  }).length;

  const trend = stats.todayCount - yesterdayCount;
  const trendPercentage = yesterdayCount > 0 ? ((trend / yesterdayCount) * 100).toFixed(1) : '0';

  // Prepare chart data
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(new Date(), 6 - i);
    const dayIssues = issues.filter((issue: any) => {
      const issueDate = new Date(issue.created_at);
      return issueDate >= startOfDay(date) && issueDate < startOfDay(subDays(date, -1));
    });

    return {
      date: format(date, 'MMM dd'),
      issues: dayIssues.length,
      reported: dayIssues.filter((issue: any) => issue.status === 'Reported').length,
      resolved: dayIssues.filter((issue: any) => issue.status === 'Resolved').length,
    };
  });

  const categoryData = categories.map((category: any) => {
    const categoryIssues = issues.filter((issue: any) => issue.category_id === category.id);
    return {
      name: category.name,
      value: categoryIssues.length,
      percentage: ((categoryIssues.length / issues.length) * 100).toFixed(1),
    };
  });

  const statusData = [
    { name: 'Reported', value: stats.reported, color: '#EF4444' },
    { name: 'In Progress', value: stats.inProgress, color: '#F59E0B' },
    { name: 'Resolved', value: stats.resolved, color: '#10B981' },
  ];

  const recentIssues = issues
    .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 5);

  const handleRefresh = async () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  const statCards = [
    {
      title: 'Total Issues',
      value: stats.total,
      icon: BarChart3,
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
      bgColor: 'bg-blue-50',
      change: `+${stats.todayCount} today`,
      changeColor: 'text-green-600'
    },
    {
      title: 'New Reports',
      value: stats.reported,
      icon: AlertTriangle,
      color: 'bg-red-500',
      textColor: 'text-red-600',
      bgColor: 'bg-red-50',
      change: trend >= 0 ? `+${trend}` : `${trend}`,
      changeColor: trend >= 0 ? 'text-green-600' : 'text-red-600'
    },
    {
      title: 'In Progress',
      value: stats.inProgress,
      icon: Clock,
      color: 'bg-yellow-500',
      textColor: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      change: `${trendPercentage}%`,
      changeColor: 'text-blue-600'
    },
    {
      title: 'Resolved',
      value: stats.resolved,
      icon: CheckCircle,
      color: 'bg-green-500',
      textColor: 'text-green-600',
      bgColor: 'bg-green-50',
      change: `${((stats.resolved / stats.total) * 100).toFixed(1)}% rate`,
      changeColor: 'text-green-600'
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between"
      >
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard Overview</h1>
          <p className="text-gray-600">Real-time analytics and system monitoring</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2"
          >
            <motion.div
              animate={refreshing ? { rotate: 360 } : {}}
              transition={{ duration: 1, ease: "linear" }}
            >
              <Activity className="h-4 w-4" />
            </motion.div>
            {refreshing ? 'Refreshing...' : 'Refresh'}
          </Button>
        </div>
      </motion.div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="overflow-hidden hover:shadow-lg transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-600 mb-1">{stat.title}</p>
                    <motion.p
                      initial={{ scale: 0.5 }}
                      animate={{ scale: 1 }}
                      transition={{ delay: index * 0.1 + 0.2, type: "spring" }}
                      className="text-3xl font-bold text-gray-900"
                    >
                      {stat.value}
                    </motion.p>
                    <div className="flex items-center gap-1 mt-2">
                      {trend >= 0 ? (
                        <ArrowUp className="h-3 w-3 text-green-600" />
                      ) : (
                        <ArrowDown className="h-3 w-3 text-red-600" />
                      )}
                      <span className={`text-xs font-medium ${stat.changeColor}`}>
                        {stat.change}
                      </span>
                    </div>
                  </div>
                  <div className={`p-3 rounded-full ${stat.bgColor}`}>
                    <stat.icon className={`h-6 w-6 ${stat.textColor}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Trend Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-blue-600" />
                Issues Trend (7 Days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={last7Days}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area
                    type="monotone"
                    dataKey="issues"
                    stroke="#3B82F6"
                    fill="#3B82F6"
                    fillOpacity={0.3}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Status Distribution */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-green-600" />
                Status Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={statusData}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percentage }: any) => `${name}: ${percentage}%`}
                  >
                    {statusData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Activity & Category Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Issues */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="lg:col-span-2"
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5 text-purple-600" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentIssues.map((issue: any, index: number) => (
                  <motion.div
                    key={issue.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.7 + index * 0.1 }}
                    className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg"
                  >
                    <div className={`p-2 rounded-full ${
                      issue.status === 'Reported' ? 'bg-red-100' :
                      issue.status === 'In Progress' ? 'bg-yellow-100' :
                      'bg-green-100'
                    }`}>
                      {issue.status === 'Reported' ? (
                        <AlertTriangle className="h-4 w-4 text-red-600" />
                      ) : issue.status === 'In Progress' ? (
                        <Clock className="h-4 w-4 text-yellow-600" />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-green-600" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{issue.title}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="outline" className="text-xs">
                          {issue.category_name}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {format(new Date(issue.created_at), 'MMM dd, HH:mm')}
                        </span>
                        {issue.flag_count > 0 && (
                          <Badge variant="destructive" className="text-xs">
                            <Flag className="h-3 w-3 mr-1" />
                            {issue.flag_count}
                          </Badge>
                        )}
                      </div>
                    </div>
                    <Button variant="ghost" size="sm">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Category Breakdown */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
        >
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5 text-indigo-600" />
                Categories
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {categoryData.map((category, index) => (
                  <motion.div
                    key={category.name}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.9 + index * 0.1 }}
                    className="space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">{category.name}</span>
                      <span className="text-sm text-gray-500">{category.value}</span>
                    </div>
                    <Progress
                      value={parseFloat(category.percentage)}
                      className="h-2"
                    />
                    <p className="text-xs text-gray-500">{category.percentage}% of total</p>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}
