// User management interface with advanced filtering and actions
import { useState } from 'react';
import { motion } from 'framer-motion';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Users, Search, UserCheck, UserX, Shield, Ban } from 'lucide-react';

export function AdminUsers() {
  const [searchQuery, setSearchQuery] = useState('');
  
  // Mock user data - would come from API in real implementation
  const users = [
    { id: 1, email: 'user1@example.com', isAdmin: false, isBanned: false, issueCount: 5, createdAt: '2024-01-15' },
    { id: 2, email: 'user2@example.com', isAdmin: false, isBanned: false, issueCount: 2, createdAt: '2024-02-01' },
    { id: 3, email: 'admin@example.com', isAdmin: true, isBanned: false, issueCount: 0, createdAt: '2024-01-01' },
  ];

  return (
    <div className="space-y-6">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <h1 className="text-2xl font-bold text-gray-900">User Management</h1>
        <p className="text-gray-600">Manage community members and permissions</p>
      </motion.div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Community Members
            </CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 w-64"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {users.map((user, index) => (
              <motion.div
                key={user.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center justify-between p-4 border rounded-lg"
              >
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarFallback>
                      {user.email.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{user.email}</h4>
                    <p className="text-sm text-gray-600">{user.issueCount} issues reported</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {user.isAdmin && <Badge><Shield className="h-3 w-3 mr-1" />Admin</Badge>}
                  {user.isBanned && <Badge variant="destructive">Banned</Badge>}
                  <Button variant="outline" size="sm">Manage</Button>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
