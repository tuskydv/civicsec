"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Play, Sparkles } from "lucide-react"

interface HeroProps {
  onGetStarted: () => void
}

export function Hero({ onGetStarted }: HeroProps) {
  return (
    <section className="relative px-4 py-20">
      <div className="mx-auto max-w-7xl">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            className="space-y-8"
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <motion.div
              className="inline-flex items-center space-x-2 bg-[var(--discord-bg-secondary)]/80 backdrop-blur-sm rounded-full px-4 py-2 text-sm border border-[var(--discord-bg-primary)]"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 300 }}
              whileHover={{ scale: 1.05 }}
            >
              <div className="h-2 w-2 bg-[#3ba55d] rounded-full animate-pulse" />
              <span className="text-[var(--discord-text-secondary)] font-medium">🚀 Building the Future</span>
            </motion.div>

            <motion.h1
              className="text-5xl lg:text-6xl font-bold leading-tight"
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
            >
              <span className="text-[var(--discord-text-primary)]">AI + Blockchain</span>
              <br />
              <span className="bg-gradient-to-r from-[#5865f2] via-[#3ba55d] to-[#faa81a] bg-clip-text text-transparent">
                Civic Revolution
              </span>
              <br />
              <span className="text-[var(--discord-text-primary)]">Starts Now</span>
            </motion.h1>

            <motion.p
              className="text-xl text-[var(--discord-text-secondary)] leading-relaxed"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5, duration: 0.5 }}
            >
              Transform your city with lightning-fast AI verification, blockchain transparency, and gamified civic
              engagement that actually works.
            </motion.p>

            <motion.div
              className="flex flex-col sm:flex-row gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7, duration: 0.5 }}
            >
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  onClick={onGetStarted}
                  className="bg-[#5865f2] hover:bg-[#4752c4] text-white shadow-lg hover:shadow-xl transition-all duration-200"
                >
                  <Sparkles className="mr-2 h-4 w-4" />
                  Start Revolution
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  size="lg"
                  variant="outline"
                  className="border-2 border-[var(--discord-bg-primary)] text-[var(--discord-text-primary)] hover:bg-[var(--discord-bg-primary)] bg-transparent backdrop-blur-sm"
                >
                  <Play className="mr-2 h-4 w-4" />
                  Watch Demo
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>

          <motion.div
            className="relative"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <div className="relative mx-auto w-80 h-[600px] bg-[var(--discord-bg-secondary)] rounded-[3rem] p-2 shadow-2xl border border-[var(--discord-bg-primary)]">
              <div className="w-full h-full bg-[var(--discord-bg-primary)] rounded-[2.5rem] p-6 overflow-hidden relative">
                <div className="flex items-center justify-between mb-6 relative z-10">
                  <h3 className="text-[var(--discord-text-primary)] font-semibold">CivicTrack</h3>
                  <div className="w-3 h-3 bg-[#3ba55d] rounded-full animate-pulse" />
                </div>

                <div className="space-y-4 relative z-10">
                  {[
                    {
                      priority: "🔥 CRITICAL",
                      title: "Pothole Crisis",
                      color: "bg-[#ed4245]/20 border-[#ed4245]/30",
                      delay: 0,
                    },
                    {
                      priority: "⚡ ACTIVE",
                      title: "Smart Light Fix",
                      color: "bg-[#faa81a]/20 border-[#faa81a]/30",
                      delay: 0.1,
                    },
                    {
                      priority: "💧 NEW",
                      title: "Water Emergency",
                      color: "bg-[#5865f2]/20 border-[#5865f2]/30",
                      delay: 0.2,
                    },
                  ].map((item, index) => (
                    <motion.div
                      key={index}
                      className={`${item.color} rounded-lg p-3 backdrop-blur-sm border`}
                      initial={{ opacity: 0, x: -30 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 1 + item.delay, duration: 0.4 }}
                      whileHover={{ scale: 1.02 }}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        <div className="w-2 h-2 bg-[#5865f2] rounded-full animate-pulse" />
                        <span className="text-[var(--discord-text-primary)] text-sm font-medium">{item.priority}</span>
                      </div>
                      <h4 className="text-[var(--discord-text-primary)] font-medium">{item.title}</h4>
                      <p className="text-[var(--discord-text-secondary)] text-sm">
                        {index === 0 && "AI-verified • +50 CivicCoins"}
                        {index === 1 && "In Progress • 12 votes"}
                        {index === 2 && "Just reported • Urgent"}
                      </p>
                    </motion.div>
                  ))}
                </div>

                <motion.div
                  className="absolute bottom-6 left-6 right-6 flex space-x-2"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1.5, duration: 0.4 }}
                >
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} className="flex-1">
                    <Button size="sm" className="w-full bg-[#5865f2] hover:bg-[#4752c4] text-white">
                      Report Issue
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      size="sm"
                      variant="outline"
                      className="border-[var(--discord-bg-tertiary)] text-[var(--discord-text-secondary)] bg-transparent backdrop-blur-sm"
                    >
                      AR View
                    </Button>
                  </motion.div>
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
